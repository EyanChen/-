

view = 0

a = lambda x : x + 1
print(a + 2)