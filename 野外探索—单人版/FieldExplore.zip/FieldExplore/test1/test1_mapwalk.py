# coding:utf-8
import pygame
from pygame.locals import *
from pygame.math import Vector2
from random import randint
from math import sqrt

SCREEN_SIZE = (640, 480)


class Map(object):
    def __init__(self, screen):
        self.screen = screen
        self.map_tip = pygame.image.load('../data/image/map/Map1.png').convert_alpha()
        self.big_img = pygame.surface.Surface(self.map_tip.get_size())
        self.big_img.fill((148, 168, 78))
        self.big_img.blit(self.map_tip, (0, 0))
        self.map_top_left = (100, 100)
        self.map_surface = self.big_img.subsurface(self.map_top_left, SCREEN_SIZE).convert_alpha()
        self.entities = []
        self.grid = 80  # 地图网格大小

    def add_entity(self, entity):
        self.entities.append(entity)
        print(self.big_img.get_size())

    def update(self, time_passed_second):
        for entity in self.entities:
            x, y = entity.position
            # 根据 player 坐标来更新要显示的map_surface
            if entity.name == 'player':
                map_x = x - SCREEN_SIZE[0] / 2
                map_y = y - SCREEN_SIZE[1] / 2
                # 判断一下有没超框
                if map_x < 0:
                    map_x = 0
                elif map_x > SCREEN_SIZE[0]:
                    map_x = SCREEN_SIZE[0]
                if map_y < 0:
                    map_y = 0
                elif map_y > SCREEN_SIZE[1]:
                    map_y = SCREEN_SIZE[1]
                self.map_top_left = (int(map_x), int(map_y))
                self.map_surface = self.big_img.subsurface(self.map_top_left, SCREEN_SIZE)
            # 判断是不是要显示的entity
            rect = pygame.Rect(self.map_top_left, SCREEN_SIZE)
            pos = (x, y)
            if rect.collidepoint(pos):
                if not entity.view:
                    entity.view = True
                entity.update(time_passed_second)
            else:
                if entity.view:
                    entity.view = False

    def render(self, screen, position):
        screen.blit(self.map_surface, (0, 0))
        self.draw_grid2(screen, position)
        for entity1 in self.entities:
            if entity1.view:
                entity1.render(screen, self.map_top_left)
                # screen.blit(entity1.img, (entity1.position - self.map_top_left))

    # 画网格,中间竖线，越靠边，间隔越宽
    def draw_grid(self, screen, position):
        x, y = position
        first_x = self.grid - x % self.grid  # 网格grid是80
        first_y = self.grid - y % self.grid
        points = []
        for i in range(0, 9):  # 屏幕9个竖线差不多了 * 实线
            start_point = (first_x + self.grid * i, 0)
            # 这里的int(self.grid**2 * 2/SCREEN_SIZE[0]) 计算偏差量
            end_point = (first_x - self.grid + int(self.grid ** 2 * 2 / SCREEN_SIZE[0]) + self.grid * i, SCREEN_SIZE[1])
            points.append((start_point, end_point))
        for i in range(0, 6):  # 横线
            start_point = (0, first_y + self.grid * i)
            end_point = (SCREEN_SIZE[0], first_y + self.grid * i)
            points.append((start_point, end_point))
        # 因为画线显示不好，改成画网点
        for s_point, e_point in points:
            for x in range(int(s_point[0]), int(e_point[0]), 8):
                for y in range(int(s_point[1]), int(e_point[1]), 8):
                    pygame.draw.circle(screen, (225, 223, 63), (x, y), 2)  # 网格点颜色 (135, 153, 63)
                    print('++')

    def draw_grid2(self, screen, position):
        x, y = position
        first_x = self.grid - int(x) % self.grid  # 网格grid是80
        first_y = self.grid - int(y) % self.grid
        points = []
        # 屏幕9个竖线差不多了 * 实线
        for i in range(0, 9):
            start_point = (first_x + self.grid * i, 0)
            # 这里的leave计算偏差量
            leave = self.grid ** 2 * 2 / SCREEN_SIZE[0] * i - self.grid
            end_point = (int(first_x + leave + self.grid * i), SCREEN_SIZE[1])
            # points += self.get_points(start_point, end_point)

        for i in range(0, 6):  # 横线
            for y in range(first_y, SCREEN_SIZE[1], self.grid):
                for x in range(0, SCREEN_SIZE[0], 8):
                    points.append((x, y))
        for pos in points:
            pygame.draw.circle(screen, (135, 153, 63), pos, 1)  # 网格点颜色 (135, 153, 63)

    def get_points(self, pos1, pos2):
        """拿到当前点与上一点之间，所有的点"""
        points = [(pos1[0], pos1[1])]
        len_x = pos2[0] - pos1[0]
        len_y = pos2[1] - pos1[1]
        length = sqrt(len_x ** 2 + len_y ** 2)
        step_x = len_x / length
        step_y = len_y / length
        for i in range(0, int(length), 20):
            points.append((points[-1][0] + step_x, points[-1][1] + step_y))
        points = map(lambda x: (int(0.5 + x[0]), int(0.5 + x[1])), points)
        return list(set(points))


class Player(object):
    def __init__(self, map1):
        self.name = 'player'
        self.img = pygame.image.load('../data/image/prop/Gold coin.png').convert_alpha()
        self.position = Vector2(300, 300)
        self.speed = 150  # 每秒走多少像素
        self.view = True
        self.map = map1
        self.direction = Vector2(0, 0)

    def render(self, screen, map_top_left):
        # 显示位置要减去个屏幕左上角位置
        screen.blit(self.img, (self.position - map_top_left))

    def update(self, time_passed_second):
        if self.direction.length():
            self.direction.normalize()
            self.position += self.direction * self.speed * time_passed_second
        x, y = self.position
        wide, high = self.img.get_size()
        map_x, map_y = self.map.big_img.get_size()
        if x <= 0:
            self.position.x = 0
        elif x >= map_x - wide / 2 - 2:
            self.position.x = map_x - wide / 2
        if y <= 0:
            self.position.y = 0
        elif y >= map_y - high / 2 - 2:
            self.position.y = map_y - high / 2
        # 把坐标取整
        self.position = Vector2(int(self.position.x), int(self.position.y))


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480), 0, 32)
    pygame.display.set_caption('FiledExplore')
    pygame.display.set_caption('Moon')

    map1 = Map(screen)
    player = Player(map1)
    map1.add_entity(player)
    clock = pygame.time.Clock()

    while True:
        time_passed = clock.tick(60)
        direction = Vector2(0, 0)
        for event in pygame.event.get():
            if event.type == QUIT:
                return
            # elif event.type == KEYDOWN:
            # 检测按键是否是a s d w 或者left,right,up,down
        pressed_keys = pygame.key.get_pressed()
        if pressed_keys[K_a] or pressed_keys[K_LEFT]:
            direction.x = -1
        if pressed_keys[K_d] or pressed_keys[K_RIGHT]:
            direction.x = 1
        if pressed_keys[K_w] or pressed_keys[K_UP]:
            direction.y = -1
        if pressed_keys[K_s] or pressed_keys[K_DOWN]:
            direction.y = 1
        if len(direction) > 0:
            player.direction = direction

        # 画地图里的东西
        map1.render(screen, player.position)
        # 更新地图
        time_passed_second = time_passed / 1000
        map1.update(time_passed_second)

        pygame.display.update()


if __name__ == '__main__':
    main()
