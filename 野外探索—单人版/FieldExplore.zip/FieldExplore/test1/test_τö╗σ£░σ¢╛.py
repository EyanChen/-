# coding:utf-8
import pygame
from pygame.locals import *

"""
地图绿色： (148, 168, 78)
"""
SCREEN_SIZE = (640, 480)
MAP_SIZE = (1080, 1080)


class Map(object):
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((640, 480), 0, 32)
        pygame.display.set_caption('Moon')
        self.db2 = pygame.image.load('../image/Map1.png').convert_alpha()
        self.map = pygame.surface.Surface(self.db2.get_size())
        self.map.fill((148, 168, 78))
        self.map.blit(self.db2, (0, 0))
        self.show_map = self.map.subsurface((100, 100), SCREEN_SIZE)
        self.screen.fill((148, 168, 78))
        self.screen.blit(self.db2, (0, 0))
        self.clock = pygame.time.Clock()

    def run(self):
        while True:
            self.clock.tick(60)
            for event in pygame.event.get():
                if event.type == QUIT:
                    exit()

            self.screen.blit(self.show_map, (0, 0))
            self.draw_grid()

            pygame.display.update()

    # 画网格,中间竖线，越靠边，间隔越宽
    def draw_grid(self):
        grid = 80
        x, y = (100, 250)
        first_x = x % grid  # 网格是80
        first_y = y % grid
        points = []
        for i in range(0, 9):  # 屏幕9个竖线差不多了 * 实线
            start_point = (first_x + grid * i, 0)
            end_point = (first_x - 150 + i * 35 + grid * i, SCREEN_SIZE[1])
            points.append((start_point, end_point))
        for i in range(0, 6):  # 横线
            start_point = (0, first_y + grid * i)
            end_point = (SCREEN_SIZE[0], first_y + grid * i)
            points.append((start_point, end_point))
        for s_point, e_point in points:
            pygame.draw.line(self.screen, (135, 153, 63), s_point, e_point, 1)


if __name__ == '__main__':
    map1 = Map()
    map1.run()
