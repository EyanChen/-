# coding : utf-8
import pygame
from pygame.locals import *
from pygame.math import Vector2

"""创建活动的实物类"""


class GameEntity(object):
    def __init__(self, map_temp, name, image):
        self.map = map_temp
        self.name = name
        self.image = image
        self.view = False  # 屏幕是否可见,默认False
        self.position = Vector2()  # 物体位置
        # self.direction_to = Vector2()  # 物体当前朝向
        self.destination = Vector2()
        self.speed = 0
        self.id = 0
        self.blood = 10  # 血量

    def render(self, surface, map_top_left):
        x, y = self.position
        weigh, high = self.image.get_size()
        surface.blit(self.image, (x - weigh / 2 - map_top_left[0], y - high / 2 - map_top_left[1]))

    def update(self, time_passed_temp, show_list):
        # 处理每一个entity的运动
        if self.speed > 0 and self.position != self.destination:
            vec = self.destination - self.position
            distance_to_destination = vec.length()  # 当前与目的地的距离
            heading = vec.normalize()
            travel_dis = min(distance_to_destination, time_passed_temp * self.speed)  # 单位速度
            self.position += travel_dis * heading

