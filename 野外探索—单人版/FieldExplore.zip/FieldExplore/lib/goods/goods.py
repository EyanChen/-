from pygame.math import Vector2
from lib.interface.Game_entity import GameEntity
from random import randint


class Tree(GameEntity):

    def __init__(self, map1, tree_img):
        GameEntity.__init__(self, map1, 'tree', tree_img)
        self.position = self.rand_position()
        # self.position = Vector2(200, 200)
        self.blood = 30

    def rand_position(self):
        rand_no = Vector2(randint(0, 1000), randint(0, 1000))
        if rand_no.x < 150 and rand_no. y < 150:
            rand_no = self.rand_position()
        return rand_no


class Rock(GameEntity):

    def __init__(self):
        pass
