import pygame
from pygame.locals import *

# SCREEN_SIZE = (640, 480)
SCREEN_SIZE = (1280, 960)


class Menu(object):

    def __init__(self, screen):
        self.screen = screen
        self.background = pygame.image.load('../data/image/background.png')
        self.font = pygame.font.SysFont('arial', 28)
        self.play_text = self.font.render('Play Game', True, (0xc0, 0xc0, 0xc0))
        self.exit_text = self.font.render('Exit', True, (0xc0, 0xc0, 0xc0))
        self.chose_player = 'sword'  # 默认战士
        self.chose_map = 'forest'  # 地图默认森林
        self.socket_switch = False  # 是否联机
        self.button_rect = [Rect((430, 330), (125, 35)),
                            Rect((430, 400), (125, 35))]
        self.player = [
            pygame.image.load('../data/image/PlayerCard/1-1.png'),
            pygame.image.load('../data/image/PlayerCard/1-2.png')
        ]
        self.player_rect = []
        for (i, player) in enumerate(self.player):
            rect = pygame.Rect(100 + i * 128 + 50 * i, 50, 128, 194)
            self.player_rect.append(rect)
        self.map = [
            pygame.image.load('../data/image/ui/forest_button.png'),
            pygame.image.load('../data/image/ui/sand_button.png')
        ]
        self.map_rect = []
        for i, surface in enumerate(self.map):
            rect = pygame.Rect(100 + i * 60 + 70 * i, 310, 60, 30)
            self.map_rect.append(rect)
        self.online = pygame.image.load('../data/image/online.png')
        self.online_rect = pygame.Rect(550, 25, 59, 27)

    def run(self, pass_time, mouse_events=None):
        self.screen.blit(self.background, (0, 0))
        # 画按扭
        for rect in self.button_rect:
            pygame.draw.rect(self.screen, (0, 112, 189), rect, 7)
        self.screen.blit(self.play_text, (440, 330))
        self.screen.blit(self.exit_text, (440, 400))
        # 画角色卡
        for i, surface in enumerate(self.player):
            self.screen.blit(surface, self.player_rect[i])
        # 画地图
        for i, surface in enumerate(self.map):
            self.screen.blit(surface, self.map_rect[i])
        # 写当前显示信息
        chose_mgs = self.font.render('Player:  ' + str(self.chose_player), True, (0xc0, 0xc0, 0xc0))
        chose_mgs2 = self.font.render('   Map:  ' + str(self.chose_map), True, (0xc0, 0xc0, 0xc0))
        self.screen.blit(chose_mgs, (100, 380))
        self.screen.blit(chose_mgs2, (100, 410))
        # 联机按钮
        self.screen.blit(self.online, self.online_rect)

        # 检查鼠标点击选择
        if mouse_events:
            for pos in mouse_events:
                result = self.check_event(pos)
                if result == 0:
                    return 'play'
                elif result == 1:
                    return 'quit'
        return 'menu'

    def check_event(self, pos):
        # 点击菜单
        for i, rect in enumerate(self.button_rect):
            if rect.collidepoint(pos):
                print('点击了菜单：' + str(i))
                return i

        # 点选角色
        for i, rect in enumerate(self.player_rect):
            if rect.collidepoint(pos):
                print('点击了角色：' + str(i))
                if i == 0:
                    self.chose_player = 'sword'
                else:
                    self.chose_player = 'master'
        # 选地图
        for i, rect in enumerate(self.map_rect):
            if rect.collidepoint(pos):
                print('点击了地图：' + str(i))
                if i == 0:
                    self.chose_map = 'forest'
                else:
                    self.chose_map = 'sand'
        # 选择联机
        for i, rect in enumerate(self.map_rect):
            if rect.collidepoint(pos):
                print('联机~')
                self.socket_switch = True

        return None
