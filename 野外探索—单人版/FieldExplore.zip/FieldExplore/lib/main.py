import pygame
from pygame.locals import *
from lib.map.map1 import Map1
from lib.map.map2 import Map2
from lib.player.swordsman import Swordsman
from lib.player.master import Master
from lib.goods.goods import Tree
from lib.player.demo import Devil
from lib.player.spider import Spider

swordsman_img_file = '../data/image/Swordsman/stand_img.png'
master_img_file = '../data/image/master/stand_32X43.png'
SCREEN_SIZE = (640, 480)
# map_SIZE = (1920, 1080)


class Main(object):

    def __init__(self, screen, player, chose_map):
        pygame.init()
        self.screen2 = pygame.display.set_mode(SCREEN_SIZE, 0, 32)
        self.screen = screen
        if chose_map == 'forest':
            self.map = Map1(screen)
        elif chose_map == 'sand':
            self.map = Map2(screen)
        if player == 'sword':
            self.player = Swordsman(self.map, pygame.image.load(swordsman_img_file).convert_alpha())
        elif player == 'master':
            self.player = Master(self.map, pygame.image.load(master_img_file).convert_alpha())
        self.map.add_entity(self.player)
        if chose_map == 'forest':
            self.init_tree()
        else:
            self.init_map2_rock()
            self.init_spider()
        self.create_animal = False

    def run(self, time_passed, direction, mouse_events=None, key_events=None):
        self.map.update(time_passed)
        self.map.render(self.screen, self.player.position)
        self.player.direction = direction
        if not self.create_animal:
            self.init_demo()
            self.create_animal = True
        if mouse_events or key_events:
            # for pos in mouse_events:
            pos = 0
            self.player.attack(time_passed, pos)

        return 'play'

    def init_demo(self):
        # 48 X 53  7帧
        demo_img = pygame.image.load('../data/image/demo1/demo1.png').convert_alpha()
        for x in range(0, 10):
            demo = Devil(self.map, demo_img)
            self.map.add_entity(demo)

    def init_spider(self):
        # 27 X 21  5帧
        demo_img = pygame.image.load('../data/image/demo1/spider_27X21.png').convert_alpha()
        for x in range(0, 10):
            demo = Spider(self.map, demo_img)
            self.map.add_entity(demo)

    def init_map2_rock(self):
        rock1 = pygame.image.load('../data/image/prop/rock1.png').convert_alpha()
        rock2 = pygame.image.load('../data/image/prop/rock2.png').convert_alpha()
        rock3 = pygame.image.load('../data/image/prop/rock3.png').convert_alpha()
        rock4 = pygame.image.load('../data/image/prop/rock4.png').convert_alpha()
        rock5 = pygame.image.load('../data/image/prop/rock6.png').convert_alpha()
        rock6 = pygame.image.load('../data/image/prop/rock6.png').convert_alpha()
        for x in range(0, 150):
            rock_img = 'rock' + str(x % 4 + 1)
            rock = Tree(self.map, eval(rock_img))
            self.map.add_entity(rock)

    def init_tree(self):
        grass1 = pygame.image.load('../data/image/prop/tree1.png').convert_alpha()
        grass2 = pygame.image.load('../data/image/prop/tree2.png').convert_alpha()
        grass3 = pygame.image.load('../data/image/prop/tree3.png').convert_alpha()
        grass4 = pygame.image.load('../data/image/prop/tree4.png').convert_alpha()
        grass5 = pygame.image.load('../data/image/prop/tree5.png').convert_alpha()
        for x in range(0, 150):
            rock_img = 'grass' + str(x % 4 + 1)
            rock = Tree(self.map, eval(rock_img))
            self.map.add_entity(rock)

