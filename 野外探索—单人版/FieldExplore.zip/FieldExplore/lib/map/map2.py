import pygame
from pygame.locals import *
from math import sqrt
from pygame.math import Vector2
from random import randint

SCREEN_SIZE = (640, 480)

"""沙漠
底色： (255, 210, 110)

"""


class Map2(object):

    def __init__(self, screen):
        self.screen = screen
        self.player = None
        self.map_tip = pygame.image.load('../data/image/map/Map2-1.png').convert_alpha()
        self.map_flower_img = pygame.image.load('../data/image/map/Map1.png').convert_alpha()
        self.bottom_frame = pygame.image.load('../data/image/ui/bottom_framer.png').convert_alpha()
        self.font1 = pygame.font.SysFont('arial', 12)
        self.font2 = pygame.font.SysFont('arial', 14)
        self.big_img = pygame.surface.Surface(self.map_tip.get_size())
        self.big_img.fill((153, 153, 153))  # (255, 210, 110)
        self.big_img.blit(self.map_tip, (0, 0))
        self.map_top_left = (0, 0)
        self.map_surface = self.big_img.subsurface(self.map_top_left, SCREEN_SIZE).convert_alpha()
        self.entities = {}
        self.show_list = []
        self.entity_id = 0  # 添加entity时赋值一个id
        self.grid = 80  # 地图网格大小
        # 地图添加花和石头
        self.draw_sand()
        self.big_img_size = self.big_img.get_size()

    def draw_sand(self):
        sand_img1 = pygame.image.load('../data/image/prop/sand1.png').convert_alpha()
        sand_img2 = pygame.image.load('../data/image/prop/sand2.png').convert_alpha()
        wide, high = self.big_img.get_size()
        for x in range(0, 100):
            sand_name = 'sand_img' + str(randint(1, 2))
            self.big_img.blit(eval(sand_name), (randint(0, wide), randint(0, high)))

    def add_entity(self, entity):
        self.entities[self.entity_id] = entity
        entity.id = self.entity_id
        self.entity_id += 1
        # print('添加了' + entity.name)

    def remove_entity(self, entity):
        del self.entities[entity.id]
        print('删掉了一个')

    def update(self, time_passed_second):
        # 找出要显示的entity放进show_list,只处理它
        for entity in self.entities.values():
            x, y = entity.position
            # 判断是不是要显示的entity, 范围加大了30
            rect = pygame.Rect((self.map_top_left[0] - 30, self.map_top_left[1] - 30),
                               (SCREEN_SIZE[0] + 60, SCREEN_SIZE[1] + 60))
            if rect.collidepoint(entity.position):
                self.show_list.append(entity)
                if not entity.view:
                    entity.view = True
            else:
                if entity.view:
                    entity.view = False
            # 根据 player 坐标来更新要显示的map_surface
            if entity.name == 'player':
                map_top_x = x - SCREEN_SIZE[0] / 2
                map_top_y = y - SCREEN_SIZE[1] / 2
                # 判断一下有没超框
                if map_top_x < 0:
                    map_top_x = 0
                elif map_top_x >= self.big_img_size[0] - SCREEN_SIZE[0]:
                    map_top_x = self.big_img_size[0] - SCREEN_SIZE[0]
                if map_top_y < 0:
                    map_top_y = 0
                elif map_top_y >= self.big_img_size[1] - SCREEN_SIZE[1]:
                    map_top_y = self.big_img_size[1] - SCREEN_SIZE[1]
                self.map_top_left = (map_top_x, map_top_y)
                self.map_surface = self.big_img.subsurface(self.map_top_left, SCREEN_SIZE)
                # if self.check_player_collide():
                #     return
                if not self.player:
                    self.player = entity
        for entity in self.show_list:
            entity.update(time_passed_second, self.show_list)
        self.show_list = []
        # print('==========================')
        # print(self.map_top_left)
        # print(self.player.position)

    def render(self, screen, position):
        # 判断一下玩家位置是不是要边界了

        screen.blit(self.map_surface, (0, 0))
        self.draw_grid(screen, position)
        # 在画之前，先按y轴排序，y大的显示在上面
        view_list = []
        for entity in self.entities.values():
            if entity.view:
                view_list.append(entity)
        # print(view_list)
        view_list.sort(key=lambda entity: entity.position.y)
        for entity in view_list:
            if entity.view:
                entity.render(screen, self.map_top_left)

        # 画左下角色信息 血条位置（60, 420）宽：42高9
        screen.blit(self.bottom_frame, (5, 410))
        screen.blit(self.player.head_img, (15, 415))
        rect = Rect((63, 425), (int(self.player.current_blood / self.player.blood * 56), 9))
        screen.fill((180, 24, 24), rect)
        text1 = self.font1.render(str(self.player.current_blood) + '/' + str(self.player.blood), True,
                                  (0xc0, 0xc0, 0xc0))
        text2 = self.font2.render('Attack: ' + str(self.player.hurt), True, (0, 0, 0))
        text3 = self.font2.render('Defence: ' + str(self.player.defence), True, (0, 0, 0))
        screen.blit(text1, (80, 422))  # 显示血量
        screen.blit(text2, (58, 435))  # 显示攻击
        screen.blit(text3, (58, 447))  # 显示防御

    # 画网格,中间竖线，越靠边，间隔越宽
    def draw_grid(self, screen, position):
        x, y = position
        first_x = self.grid - x % self.grid  # 网格grid是80
        first_y = self.grid - y % self.grid
        points = []
        # 画竖线
        if x < SCREEN_SIZE[0] / 2:
            pos_x = self.grid - SCREEN_SIZE[0] / 2 % self.grid
            for i in range(0, 8):
                start_point = (pos_x + self.grid * i, 0)
                end_point = (int((start_point[0] - self.grid * 2) * 1.9), SCREEN_SIZE[1])
                points.append((start_point, end_point))
        elif x > self.big_img.get_size()[0] - SCREEN_SIZE[0] / 2:
            pos_x = self.big_img.get_size()[0] - SCREEN_SIZE[0] / 2
            for i in range(0, 8):
                start_point = (pos_x + self.grid * i, 0)
                end_point = (int((start_point[0] - self.grid * 2) * 1.9), SCREEN_SIZE[1])
                points.append((start_point, end_point))
        else:
            for i in range(0, 8):  # 屏幕8个竖线 * 实线
                start_point = (first_x + self.grid * i, 0)
                end_point = (int((start_point[0] - self.grid * 2) * 1.9), SCREEN_SIZE[1])
                points.append((start_point, end_point))
        # 画横线
        if y < SCREEN_SIZE[1] / 2:
            pos_y = self.grid - SCREEN_SIZE[1] / 2 % self.grid
            for i in range(0, 6):
                start_point = (0, + pos_y + self.grid * i)
                end_point = (SCREEN_SIZE[0], pos_y + self.grid * i)
                points.append((start_point, end_point))
        elif y > self.big_img.get_size()[0] - SCREEN_SIZE[1] / 2:
            pos_y = self.big_img.get_size()[0] - SCREEN_SIZE[1] / 2
            for i in range(0, 6):
                start_point = (0, pos_y + self.grid * i)
                end_point = (SCREEN_SIZE[0], pos_y + self.grid * i)
                points.append((start_point, end_point))
        else:
            for i in range(0, 6):
                start_point = (0, first_y + self.grid * i)
                end_point = (SCREEN_SIZE[0], first_y + self.grid * i)
                points.append((start_point, end_point))
        # 画线
        for s_point, e_point in points:
            pygame.draw.line(screen, (130, 122, 97), s_point, e_point, 1)  # 沙漠网格点颜色 (130, 122, 97)

    # 先不用这种画网格方法
    def draw_grid2(self, screen, position):
        x, y = position
        first_x = self.grid - int(x) % self.grid  # 网格grid是80
        first_y = self.grid - int(y) % self.grid
        points = []
        # 屏幕9个竖线差不多了 * 实线
        for i in range(0, 9):
            start_point = (first_x + self.grid * i, 0)
            # 这里的leave计算偏差量
            leave = self.grid ** 2 * 2 / SCREEN_SIZE[0] * i - self.grid
            end_point = (int(first_x + leave + self.grid * i), SCREEN_SIZE[1])
            # points += self.get_points(start_point, end_point)

        for i in range(0, 6):  # 横线
            for y in range(first_y, SCREEN_SIZE[1], self.grid):
                for x in range(first_x, SCREEN_SIZE[0], 15):
                    points.append((x, y))
        for pos in points:
            pygame.draw.circle(screen, (135, 153, 63), pos, 1)  # 网格点颜色 (135, 153, 63)

    def get_points(self, pos1, pos2):
        """拿到当前点与上一点之间，所有的点，留着待用"""
        points = [(pos1[0], pos1[1])]
        len_x = pos2[0] - pos1[0]
        len_y = pos2[1] - pos1[1]
        length = sqrt(len_x ** 2 + len_y ** 2)
        step_x = len_x / length
        step_y = len_y / length
        for i in range(0, int(length), 20):
            points.append((points[-1][0] + step_x, points[-1][1] + step_y))
        points = map(lambda x: (int(0.5 + x[0]), int(0.5 + x[1])), points)
        return list(set(points))
