from socket import *


class SocketOnline(object):

    def __init__(self):
        self.socket = socket(AF_INET, SOCK_STREAM)
        self.socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)  # 重用绑定信息
        self.local_addr = ('', 12321)
        self.socket.bind(self.local_addr)
        self.socket.listen(4)

    def loop(self):
        pass
