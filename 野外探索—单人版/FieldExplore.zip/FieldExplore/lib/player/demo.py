import pygame
from pygame.math import Vector2
from lib.interface.Game_entity import GameEntity
from random import randint

"""恶魔类Devil"""


# 48 X 53  7帧

class Devil(GameEntity):
    def __init__(self, map1, demo_img):
        GameEntity.__init__(self, map1, 'demo', demo_img)
        self.position = Vector2(randint(0, 1000), randint(0, 1000))
        # self.position = Vector2(200, 200)
        self.image_now = self.image.subsurface((0, 0), (48, 53))
        self.speed = 100
        self.frame_wide = 48
        self.frame_high = 53
        self.frame_now = 0  # 当前是第几帧
        self.time = 0
        self.frame_speed = 8  # 每秒多少帧
        self.destination = self.position
        self.direction_to = Vector2()
        self.find_area = 500  # 侦查范围
        self.blood = 40 + randint(-10, 10)
        self.defence = 5

    def render(self, surface, map_top_left):
        self.image_now = self.image.subsurface((self.frame_wide * self.frame_now, 0), (self.frame_wide, self.frame_high))
        wide, high = self.image_now.get_size()
        draw_pos = (self.position.x - map_top_left[0] - wide/2, self.position.y - map_top_left[1] - high/2)
        if self.direction_to.x > 0:
            surface.blit(self.image_now, draw_pos)
        else:
            flip_img = pygame.transform.flip(self.image_now, 1, 0)
            surface.blit(flip_img, draw_pos)

    def update(self, time_passed_second, show_list):
        # 更新位置
        GameEntity.update(self, time_passed_second, show_list)
        # 随机目的地
        # if randint(0, 800) == 1:
        #     direction = Vector2(self.position.x + randint(-400, 400), self.position.y + randint(-400, 400))
        #     if 0 < direction.x < 1000 and 0 < direction.y < 1000 :
        #         self.destination = direction
        self.check_frame(time_passed_second)
        # 检查与玩家的距离，靠近了，就改变方向到玩家位置

        vector = self.map.player.position - self.position
        if self.find_area < vector.length():
            if randint(0, 1000) == 1:
                self.destination = self.map.player.position
                print('+_+_+_+__+')
                print(self.destination)
                print(self.map.player.position)

    def check_frame(self, time_passed_second):
        self.time += time_passed_second
        if (1 / self.frame_speed) < self.time:
            self.frame_now += 1
            self.time = 0
        if self.frame_now >= 7:
            self.frame_now = 0
