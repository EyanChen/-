from pygame.locals import *
from lib.interface.Game_entity import GameEntity
from lib.skill.skill import *

SCREEN_SIZE = (640, 480)


class Swordsman(GameEntity):

    def __init__(self, map1, player_img):
        GameEntity.__init__(self, map1, 'player', player_img)
        self.position = Vector2(20, 20)
        self.speed = 200  # 每秒走多少像素
        self.view = True  # 屏幕是否可见
        self.walk_img = pygame.image.load('../data/image/Swordsman/walk_img.png')
        self.attack_img = pygame.image.load('../data/image/Swordsman/wi_img.png')
        self.head_img = pygame.image.load('../data/image/ui/swordsman_head.png')
        self.img = player_img.subsurface((0, 0), (34, 50)).convert_alpha()
        self.direction = Vector2(0, 0)  # 速度方向
        self.direction_to = Vector2()  # 人物方向
        self.img_w = self.img.get_size()[0]  # 34 X 50
        self.img_h = self.img.get_size()[1]
        self.frame_now = 0  # 当前是第几帧
        self.time = 0  # 更新角色帧用的时间
        self.frame_speed = 10  # 角色每秒多少帧
        self.a = Rect(0, 0, 0, 0)  # 测试用
        self.state = 'calm'  # 三个状态attack 攻击  calm 平静 violent 猛烈
        self.add_up_time = 0  # 累加时间
        self.skills = {'general_attack': Skill1(self, map1),
                       'second_attack': Skill2(self, map1)}
        self.show_list = []  # 可见范围内的entities
        self.blood = 50  # 当前血量
        self.current_blood = self.blood
        self.hurt = 7
        self.defence = 7

    def render(self, screen, map_top_left):
        # 显示到实际地图上的位置
        self.a[0] -= self.map.map_top_left[0]
        self.a[1] -= self.map.map_top_left[1]
        screen.fill((0, 0, 0), self.a)  # 测试用，画碰撞范围
        # self.a = Rect(0, 0, 0, 0)
        # 判断角色当前在哪种状态，截取哪个的surface
        if self.state == 'calm':
            if self.direction.x != 0 or self.direction.y != 0:
                new_frame = self.walk_img.subsurface((self.frame_now * self.img_w, 0), (34, 50)).convert_alpha()
            else:
                new_frame = self.image.subsurface((self.frame_now * self.img_w, 0), (34, 50)).convert_alpha()
        elif self.state == 'attack':
            new_frame = self.attack_img.subsurface((self.frame_now * self.img_w, 0), (34, 50)).convert_alpha()
        # 判断方向
        if self.direction_to.x < 0:
            screen.blit(new_frame, (self.position - map_top_left - (self.img_w/2, self.img_h/2)))
        else:
            # 转向
            new_frame = pygame.transform.flip(new_frame, 1, 0)
            screen.blit(new_frame, (self.position - map_top_left - (self.img_w/2, self.img_h/2)))
        # 是否放技能
        if self.state == 'attack':
            skill = self.skills['general_attack']
            skill.render(screen, map_top_left)

            # else:
            #     new_img = pygame.transform.flip(self.skill_1.image, 1, 0)
            #     screen.blit(new_img, self.position - map_top_left - (self.img_w / 2, self.img_h / 2) + (20, 0))

    def update(self, time_passed_second, show_list):
        self.add_up_time += time_passed_second
        self.show_list = show_list
        if self.direction.length():
            self.direction_to = self.direction
            self.direction = self.direction.normalize()
            new_pos = self.position + self.direction * self.speed * time_passed_second
            if not self.check_player_collide(new_pos, show_list):
                self.position = Vector2(new_pos.x, new_pos.y)

        x, y = self.position
        wide, high = self.img.get_size()
        map_x, map_y = self.map.big_img.get_size()
        # 检测地图边界
        if x <= wide / 2:
            self.position.x = wide / 2
        elif x >= map_x - wide / 2:
            self.position.x = map_x - wide / 2
        if y <= high / 2:
            self.position.y = high / 2
        elif y >= map_y - high / 2:
            self.position.y = map_y - high / 2

        # 把坐标取整
        self.position = Vector2(int(self.position.x), int(self.position.y))
        # 更新一下角色动画
        self.check_frame(time_passed_second)
        # 更新一下技能
        if self.state == 'attack':
            self.skills['general_attack'].update(time_passed_second, self.position, self.direction_to)

    def check_player_collide(self, new_pos, show_list):
        # 碰撞检测，如：计算两者之间position距离是否大于两者图片size的一半
        x, y = new_pos
        for entity3 in show_list:
            if entity3.name == 'tree':
                rect1 = entity3.image.get_rect()
                wide, high = rect1[2], rect1[3]
                rect = Rect((entity3.position.x - wide / 2, entity3.position.y - high / 4), (rect1[2], rect1[3] - high /3))
                if rect.collidepoint(new_pos.x, new_pos.y):
                    return True

            elif entity3.name == 'demo':
                wide, high = entity3.image_now.get_size()
                new_w = (self.img_w + wide) / 2
                new_h = (self.img_h + high) / 2
                vector = Rect((x - new_w + 10, y - new_h + 10), (new_w * 2 - 20, new_h * 2 - 20))
                # self.a = vector
                if vector.collidepoint(entity3.position):
                    return True

            # elif entity3.name == 'demo':
            #     rect1 = entity3.img.get_rect()
            #     wide, high = rect1[2], rect1[3]
            #     rect = Rect((entity3.position.x - wide / 3, entity3.position.y), (rect1[2] + 20, rect1[3] - high / 3))
            #     if rect.collidepoint(new_pos.x, new_pos.y):
            #         return True

    def attack(self, time_passed, mouse_pos):
        # 判断一下技能CD有没有好
        if self.add_up_time - self.skills['general_attack'].last_play_time > self.skills['general_attack'].CD:
            self.state = 'attack'
            collide_entity = self.check_skill_collide(self.skills['general_attack'])
            if len(collide_entity):
                self.skills['general_attack'].cal_hurt(collide_entity)  # 撞到技能的物体减去血量
            self.skills['general_attack'].last_play_time = self.add_up_time

    def check_frame(self, time_passed_second):
        self.time += time_passed_second
        if (1 / self.frame_speed) < self.time:
            self.frame_now += 1
            self.time = 0
        if self.frame_now >= 4:  # stand : 5帧
            self.frame_now = 0

    def check_skill_collide(self, skill):
        entities = []  # 技能打到的entity都放进来
        x, y = skill.position
        skill_img_x = skill.frame_w
        skill_img_y = skill.frame_h
        for entity in self.show_list:
            if entity.name == 'tree' or entity.name == 'demo':
                wide, high = entity.image_now.get_size()
                new_w = (skill_img_x + wide) / 2
                new_h = (skill_img_y + high) / 2
                # 这里技能的位置也要加上个技能偏移量
                if self.direction_to.x < 0:
                    vector = Rect((x - new_w + 10, y - new_h + 10) + skill.deviation, (new_w * 2 - 20, new_h * 2 - 20))
                else:
                    vector = Rect((x - new_w + 10, y - new_h + 10) - skill.deviation, (new_w * 2 - 20, new_h * 2 - 20))
                # self.a = vector
                if vector.collidepoint(entity.position):
                    entities.append(entity)
        return entities


