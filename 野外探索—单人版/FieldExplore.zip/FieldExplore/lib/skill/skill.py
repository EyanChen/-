import pygame
from pygame.math import Vector2
from lib.interface.Skill import Skill


class Skill1(Skill):  # 剑士普攻
    def __init__(self, player, map1, direction=None):
        Skill.__init__(self, player, map1, 'general_attack', direction)
        self.frame_No = 4  # 总共多少帧
        self.frame_w = 64
        self.frame_h = 80
        self.image = pygame.image.load('../data/image/skill/skill1_64X80.png').convert_alpha()
        self.deviation = Vector2(-35, 0)
        self.frame_speed = 14
        self.hold_time = 0.3
        self.hurt = 5
        self.CD = 0.5


class Skill2(Skill):  # 剑士锤地
    def __init__(self, player, map1, direction=None):
        Skill.__init__(self, player, map1, 'hammer', direction)
        self.frame_No = 1  # 总共多少帧
        self.image = pygame.image.load('../data/image/skill/skill2.png').convert_alpha()
        self.frame_speed = 8


class Skill3(Skill):  # 箭手普攻
    def __init__(self, player, map1, direction=None):
        Skill.__init__(self, player, map1, 'general_attack', direction)
        self.frame_No = 0  # 总共多少帧
        self.image = pygame.image.load('../data/image/skill/skill3.png').convert_alpha()
        self.frame_speed = 8


class Skill4(Skill):  # 箭手特攻
    def __init__(self, player, map1, direction=None):
        Skill.__init__(self, player, map1, 'special_attack', direction)
        self.frame_No = 0  # 总共多少帧
        self.image = pygame.image.load('../data/image/skill/skill3.png').convert_alpha()
        self.frame_speed = 8


class Skill5(Skill):  # 法师普攻
    def __init__(self, player, map1, direction=None):
        Skill.__init__(self, player, map1, 'general_attack', direction)
        self.frame_No = 10  # 总共多少帧
        self.image = pygame.image.load('../data/image/skill/skill5_150X150.png').convert_alpha()
        self.frame_speed = 10
        self.frame_w = 150
        self.frame_h = 150
        self.deviation = Vector2(-75, 0)
        self.hold_time = 0.8
        self.hurt = 10
        self.CD = 1
