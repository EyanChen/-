import pygame
from pygame.math import Vector2
from pygame.rect import Rect


class Skill(object):
    def __init__(self, player, map1, name, direction_to):
        self.name = name
        self.player = player
        self.map = map1
        self.image = None
        self.frame_w = 0
        self.frame_h = 0
        self.img_now = None
        self.hit_img = pygame.image.load('../data/image/skill/hit_img.png')  # 击中的小图片
        self.position = Vector2(0, 0)
        self.deviation = Vector2(0, 0)  # 画技能时的偏移量
        self.direction_to = direction_to  # 技能方向
        self.frame_No = 0  # 总共多少帧
        self.frame_now_No = 0
        self.speed = 0  # 技能运行速度
        self.frame_speed = 0  # 帧速度
        self.frame_time = 0  # 当前帧时间
        self.hold_time = 0  # 技能保持时间(总共施放多长时间)
        self.elapsed_time = 0  # 记录当前技能已用时间
        self.CD = 0.1  # 技能冷却时间默认0.1
        self.last_play_time = 0  # 上次施放计时.累加的
        self.hurt = 0
        self.hurt_area = Rect(0, 0, 0, 0)  # 技能攻击范围
        self.is_continued = False  # 是否持续技能
        self.state = 'calm'  # attack 攻击  calm 平静 violent 猛烈(爆炸)
        self.hurt_entities = []
        self.move_skill = False  # 技能位置是否移动，默认false

    def render(self, screen, map_top_left=(0, 0)):
        self.img_now = self.image.subsurface(self.frame_w * self.frame_now_No, 0, self.frame_w, self.frame_h)
        x, y = self.img_now.get_size()
        if self.direction_to.x < 0:
            screen.blit(self.img_now, self.position - map_top_left - (x/2, y/2) + self.deviation)
        else:
            self.img_now = pygame.transform.flip(self.img_now, 1, 0)
            screen.blit(self.img_now, self.position - map_top_left - (x/2, y/2) - self.deviation)
        # 画击中的动画
        hit_x, hit_y = self.hit_img.get_size()
        for entity in self.hurt_entities:
            screen.blit(self.hit_img, (entity.position - map_top_left - (hit_x/2, hit_y/2)))
        self.hurt_entities = []

    def update(self, time_passed_second, pos, direction_to):
        if self.move_skill:
            self.position = pos
        self.direction_to = direction_to
        # 更新速度
        if self.speed > 0:
            heading = self.direction_to.normalize()
            self.position += heading * self.speed

        # 更新帧
        self.frame_time += time_passed_second
        if (1 / self.frame_speed) < self.frame_time:
            self.frame_now_No += 1
            self.frame_time = 0
        if self.frame_now_No >= self.frame_No:  # stand : 5帧
            self.frame_now_No = 0

        # 更新已用时间,超过就改变状态
        self.elapsed_time += time_passed_second
        if self.elapsed_time > self.hold_time:
            self.player.state = 'calm'
            self.elapsed_time = 0

    def cal_hurt(self, entities):
        self.hurt_entities = entities
        for entity in entities:
            entity.blood -= (self.hurt / entity.defence) * self.hurt
            print(entity.blood)
            if entity.blood <= 0:
                self.map.remove_entity(entity)
