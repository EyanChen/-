# coding : uft-8
import pygame
from lib.menu import *
from lib.main import *
from pygame.math import Vector2

"""进程主体部分"""


class Game(object):
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode(SCREEN_SIZE, 0, 32)
        self.icon_img = pygame.image.load('../data/image/prop/Gold coin.png')
        pygame.display.set_caption('FieldExplore')
        pygame.display.set_icon(self.icon_img)
        self.clock = pygame.time.Clock()
        self.stat = 'menu'  # 默认打开的是界面
        self.mouse_events = []
        self.key_events = []
        self.frame = 0
        self.sum1 = 0
        self.choice_player = None
        self.choice_map = None
        self.menu = Menu(self.screen)
        self.Main = None  #Main(self.screen, self.choice_player, self.choice_map)
        self.online_msg = None

    def run(self):
        while self.stat != 'quit':
            time_passed = self.clock.tick(60)
            time_passed_second = time_passed / 1000
            for event in pygame.event.get():
                if event.type == QUIT:
                    return
                if event.type == MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    self.mouse_events.append(mouse_pos)

                # 按键写到这里
            direction = Vector2(0, 0)
            pressed_keys = pygame.key.get_pressed()
            if pressed_keys[K_a] or pressed_keys[K_LEFT]:
                direction.x = -1
            if pressed_keys[K_d] or pressed_keys[K_RIGHT]:
                direction.x = 1
            if pressed_keys[K_w] or pressed_keys[K_UP]:
                direction.y = -1
            if pressed_keys[K_s] or pressed_keys[K_DOWN]:
                direction.y = 1
            if pressed_keys[K_SPACE]:
                self.key_events.append(pressed_keys)

                # 检测状态，看进哪个state
            if self.stat == 'menu':
                if len(self.mouse_events):
                    self.stat = self.menu.run(time_passed_second, self.mouse_events)
                    self.mouse_events = []
                else:
                    self.stat = self.menu.run(time_passed_second)
                if self.stat == 'play':
                    if not self.choice_map:
                        self.choice_map = self.menu.chose_map
                        self.choice_player = self.menu.chose_player
                        self.Main = Main(self.screen, self.choice_player, self.choice_map)
                    print('更换了菜单界面')
            elif self.stat == 'play':
                if len(self.mouse_events) or len(self.key_events):
                    self.stat = self.Main.run(time_passed_second, direction, self.mouse_events, self.key_events)
                    self.mouse_events = []
                    self.key_events = []
                else:
                    self.stat = self.Main.run(time_passed_second, direction)
            elif self.stat == 'quit':
                return

            pygame.display.update()
            # 输出一下帧
            self.sum1 += time_passed
            self.frame += 1
            if self.sum1 > 1000:
                # print(self.frame)
                self.frame = 0
                self.sum1 = 0


if __name__ == '__main__':
    game = Game()
    game.run()
    print('End!')
