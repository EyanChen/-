# coding : uft-8
import sys
import os


lib_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'lib')
sys.path.insert(0, lib_dir)
print(sys.path)

import game
game = Game()
game.run()