import datetime
import time

s_time = time.ctime()
# time.sleep(0.1)
# coast_time = time.time() - s_time
print(s_time)