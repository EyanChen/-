from tkinter import *
from tkinter import filedialog
from tkinter import ttk
from checkexcel.check import *
from checkexcel.gl import version_list

root = Tk()
root.title('Excel检查~')
root.geometry('640x480')


def open_file():
    global file_path
    file_path = filedialog.askopenfilename()
    print(file_path)
    var.set(file_path)


def loading_file():
    global file_path
    msgs = load_files(file_path)
    t.insert('end', msgs)
    t.insert('end', '\n')


def check_action():
    msgs = check()
    if msgs:
        for msg in msgs:
            t.insert('end', msg)
            t.insert('end', '\n')


frame_top = Frame(root,bg='lightblue',width=640,height=40)
tips = Label(frame_top, text='文件路径：', height=1, width=11, padx=5, pady=5, bg='lightblue')
var = StringVar()
var.set('- - 请选择文件路径- -')
Fpath = Entry(frame_top, textvariable=var, justify=LEFT, width=50)

open_button = Button(frame_top, text='打开', command=open_file)
add_button = Button(frame_top, text='加载', command=loading_file)
tips.place(x=2,y=2)
Fpath.place(x=70,y=8)
open_button.place(x=450, y=2)
add_button.place(x=500, y=2)
frame_top.pack()
# 版本等条件选择
l1 = Label(root, text='选择版本: ', )
l1.place(x=5, y=50)
var2 = StringVar()
var2.set('选择版本')

cb1 = ttk.Combobox(root, width=3)  # 下拉控件1
cb1.place(x=64, y=51)
cb1['value'] = version_list
cb1.current(0)

cb2 = ttk.Combobox(root, width=4)  # 下拉控件2
cb2.place(x=124, y=51)
cb2['value'] = ('简体', '繁体')
cb2.current(0)

# 检查

check_button = Button(root, text='检查', command=check_action)
check_button.place(x=184, y=48)

# 文本框输出
t = Text(root,height=24,width=77)
t.place(x=5, y=85)
# 加个拖动条
scroll = Scrollbar()
scroll.pack(side=RIGHT, fill=Y)
# scroll.place(x=625, y=85)
scroll.config(command=t.yview)
t.config(yscrollcommand=scroll.set)


root.mainloop()
