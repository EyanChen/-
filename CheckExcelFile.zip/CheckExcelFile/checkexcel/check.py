# import checkexcel.load_files
from checkexcel.load_files import *
from checkexcel.check_fire_table import *

def check():

    All_msg = []
    # 检查fire_table
    msgs1 = check_fire_table()
    for msg in msgs1:
        All_msg.append(msg)

    # 检查grass_table
    # msgs2 = check_grass_table()
    # for msg in msgs2:
    #     All_msg.append(msg)

    return All_msg






