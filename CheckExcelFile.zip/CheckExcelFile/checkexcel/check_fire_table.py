
from checkexcel.load_files import *


def check_fire_table():
    sheet2 = get_sheet_by_name('fire_table')
    nrows = sheet2.nrows
    skill_list = sheet2.col_values(3, start_rowx=1,end_rowx=nrows)
    print(skill_list)
    sheet3 = get_sheet_by_name('skill')
    skill_nrows = sheet3.nrows
    skill_no = sheet3.col_values(0, start_rowx=1,end_rowx=skill_nrows)
    error_skill = []
    for i, skill in enumerate(skill_list):
        if skill not in skill_no:
            error_skill.append((i, skill))
    All_msg = []
    for i, skill in error_skill:
        All_msg.append('第'+ str(i) + '行，技能' + str(skill) + '错误')
    return All_msg