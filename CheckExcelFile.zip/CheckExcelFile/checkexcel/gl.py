

# 要检查文件路径
file_path = None

# 版本list
version_list = ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10')

# 表单s
BOOK = None