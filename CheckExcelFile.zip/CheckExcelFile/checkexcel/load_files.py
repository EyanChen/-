import xlrd
import time


def load_files(path):
    global BOOK
    filename = path.split('/')[-1]
    start_time = time.time()
    if path:
        try:
            BOOK = xlrd.open_workbook(path)
        except FileNotFoundError as e:
            return '文件加载失败'
    else:
        return None
    end_time = time.time()
    coast_time = end_time - start_time

    return_msg = filename + '加载成功,消耗时间：' + '%.3f' % coast_time + '秒'
    return return_msg


def load_sheet1():
    sheet1 = BOOK.sheets()[0]
    return sheet1


def load_sheet2():
    sheet2 = BOOK.sheets()[1]
    return sheet2


def load_table_names():
    names = BOOK.sheet_names()
    print(names)


def get_sheet_by_name(name):
    return BOOK.sheet_by_name(name)